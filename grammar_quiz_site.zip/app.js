
const TOTAL_MODELS = 48;
const tabsEl = document.getElementById('tabs');
const quizEl = document.getElementById('quiz');
const scoreBox = document.getElementById('scoreBox');
const modelTitle = document.getElementById('modelTitle');
const submitBtn = document.getElementById('submitBtn');
const resetBtn = document.getElementById('resetBtn');
const teacherBtn = document.getElementById('teacherBtn');

let currentIndex = 1;
let teacherMode = false;
let currentData = null;

function makeTab(i, count){
  const btn = document.createElement('button');
  btn.className = 'tab'+(i===currentIndex?' active':'');
  btn.textContent = `النموذج ${i}`;
  const badge = document.createElement('span');
  badge.className = 'count';
  badge.textContent = `(${count})`;
  btn.appendChild(badge);
  btn.addEventListener('click', ()=> switchTo(i));
  return btn;
}

async function loadModel(i){
  const res = await fetch(`data/model${String(i).padStart(2,'0')}.json`);
  const data = await res.json();
  return data;
}

async function buildTabs(){
  tabsEl.innerHTML = '';
  for (let i=1;i<=TOTAL_MODELS;i++){
    try{
      const data = await loadModel(i);
      const count = (data.questions||[]).length;
      tabsEl.appendChild(makeTab(i, count));
    }catch(e){
      const btn = makeTab(i, 0);
      tabsEl.appendChild(btn);
    }
  }
}

function renderQuiz(data){
  currentData = data;
  scoreBox.innerHTML = '';
  quizEl.innerHTML = '';
  modelTitle.innerHTML = `النموذج الحالي: <b>${data.title||('النموذج '+data.model)}</b> <span class="badge">${(data.questions||[]).length} سؤال</span>`;

  if (!data.questions || !data.questions.length){
    quizEl.innerHTML = `<div class="card meta">لا توجد أسئلة في هذا التبويب بعد.</div>`;
    return;
  }

  data.questions.forEach((q, idx)=>{
    const card = document.createElement('div');
    card.className = 'card q-card';
    card.dataset.qindex = idx;

    const qt = document.createElement('div');
    qt.className = 'q-text';
    qt.textContent = (idx+1)+'. '+ q.q;
    card.appendChild(qt);

    const choices = document.createElement('div');
    choices.className = 'choices';
    (q.a||[]).forEach((text, i)=>{
      const row = document.createElement('label');
      row.className = 'choice';
      const radio = document.createElement('input');
      radio.type = 'radio';
      radio.name = 'q'+idx;
      radio.value = i;
      row.appendChild(radio);
      const span = document.createElement('span');
      span.textContent = text;
      row.appendChild(span);

      if (teacherMode){
        // click to mark correct
        row.addEventListener('dblclick', ()=> {
          q.correct = i;
          // visual
          row.classList.add('correct');
          [...choices.children].forEach((c,j)=>{ if(j!==i) c.classList.remove('correct'); });
        });
      }

      choices.appendChild(row);
    });
    card.appendChild(choices);

    if (teacherMode){
      const hint = document.createElement('div');
      hint.className = 'meta';
      hint.textContent = 'وضع المعلّم: انقري نقرتين مزدوجة على الخيار الصحيح لحفظه.';
      card.appendChild(hint);
    }

    quizEl.appendChild(card);
  });
}

async function switchTo(i){
  currentIndex = i;
  document.querySelectorAll('.tab').forEach(t=>t.classList.remove('active'));
  tabsEl.children[i-1].classList.add('active');
  const data = await loadModel(i);
  renderQuiz(data);
  window.scrollTo({top:0,behavior:'smooth'});
}

submitBtn.addEventListener('click', ()=>{
  if (!currentData || !currentData.questions) return;
  // remove previous results
  document.querySelectorAll('.result').forEach(x=>x.remove());
  let correctCount = 0, total = currentData.questions.length;
  currentData.questions.forEach((q, idx)=>{
    const chosen = document.querySelector(`input[name="q${idx}"]:checked`);
    const card = document.querySelector(`.q-card[data-qindex="${idx}"]`);
    const res = document.createElement('div');
    res.className='result';

    const correctIdx = (typeof q.correct === 'number') ? q.correct : null;
    if (chosen && correctIdx !== null && Number(chosen.value)===correctIdx){
      correctCount++;
      res.classList.add('ok');
      res.innerHTML = '✔️ إجابة صحيحة';
      card.querySelectorAll('.choice')[correctIdx]?.classList.add('correct');
    }else{
      res.classList.add('bad');
      const your = chosen ? q.a[Number(chosen.value)] : '— لم تُجِب —';
      const correctText = (correctIdx !== null) ? q.a[correctIdx] : '— (لم تُحدَّد بعد) —';
      res.innerHTML = `❌ إجابة غير صحيحة<br><div class="explain"><b>الصحيح:</b> ${correctText}${q.explain?('<br>'+q.explain):''}</div>`;
      if (chosen) card.querySelectorAll('.choice')[Number(chosen.value)]?.classList.add('wrong');
      if (correctIdx !== null) card.querySelectorAll('.choice')[correctIdx]?.classList.add('correct');
    }
    card.appendChild(res);
  });
  const score = Math.round(100 * correctCount / (currentData.questions.length||1));
  scoreBox.innerHTML = `<div class="card"><div class="q-text">نتيجتك: ${correctCount} / ${currentData.questions.length} — ${score}%</div></div>`;
  window.scrollTo({top:0,behavior:'smooth'});
});

resetBtn.addEventListener('click', ()=>{
  document.querySelectorAll('input[type=radio]').forEach(r=> r.checked=false);
  document.querySelectorAll('.result').forEach(x=>x.remove());
  document.querySelectorAll('.choice').forEach(x=>x.classList.remove('wrong','correct'));
  scoreBox.innerHTML='';
});

teacherBtn.addEventListener('click', ()=>{
  teacherMode = !teacherMode;
  teacherBtn.textContent = teacherMode ? 'خروج من وضع المعلّم' : 'وضع المُعلّم';
  // إعادة الرسم لتفعيل الدبل-كليك
  renderQuiz(currentData||{questions:[]});
  if (teacherMode){
    // إضافة زر تنزيل JSON للموديل الحالي
    if (!document.getElementById('downloadBtn')){
      const dl = document.createElement('button');
      dl.id='downloadBtn';
      dl.className='btn ghost';
      dl.textContent='تنزيل JSON لهذا النموذج';
      dl.addEventListener('click', ()=>{
        const blob = new Blob([JSON.stringify(currentData,null,2)], {type:'application/json'});
        const a = document.createElement('a');
        a.href = URL.createObjectURL(blob);
        a.download = `model${String(currentIndex).padStart(2,'0')}.json`;
        a.click();
        URL.revokeObjectURL(a.href);
      });
      document.querySelector('.toolbar').insertBefore(dl, submitBtn);
    }
  }else{
    document.getElementById('downloadBtn')?.remove();
  }
});

(async function init(){
  await buildTabs();
  await switchTo(1);
})();
